# Project Prompt: SmartMart – A Web-Based Convenience Store Inventory and Sales Management System

## Project Overview

Develop a full-stack web application named **SmartMart: A Web-Based Convenience Store Inventory and Sales Management System**.

The system is designed for a convenience store to manage products, inventory, sales transactions, customers, staff, and reports. The store operates on a **walk-in only** basis. Customers cannot purchase or pay online. Instead, they use the website to browse available products, check prices, view stock availability, and monitor their purchase history. All purchases are completed physically inside the store using a Point of Sale (POS) module.

The system must implement **Role-Based Access Control (RBAC)** with three user roles:

* Admin
* Staff (Cashier)
* Customer

---

# System Objectives

The system should:

* Digitize inventory management.
* Replace manual sales recording.
* Allow customers to browse products before visiting the store.
* Process walk-in purchases through a POS system.
* Automatically update inventory after every completed sale.
* Generate reports for business monitoring.

---

# User Roles

## 1. Admin

The Admin has full system access.

### Features

* Secure Login
* Dashboard
* Manage Staff Accounts
* Manage Customer Accounts
* Manage Product Categories
* Add/Edit/Delete Products
* Upload Product Images
* Manage Inventory
* Restock Products
* View Low Stock Alerts
* View Sales Reports
* View Best-Selling Products
* View Monthly Revenue
* Search Products
* Manage Store Settings

---

## 2. Staff (Cashier)

The Staff operates the Point of Sale system.

### Features

* Secure Login
* Dashboard
* POS (Point of Sale)
* Search Products
* Scan Barcode (optional)
* Add Products to Cart
* Remove Products
* Change Quantity
* Compute Total
* Accept Cash Payment
* Calculate Change Automatically
* Print Receipt
* Save Transaction
* Automatically Update Inventory
* Search Customer Account
* Link Purchase to Customer
* View Today's Transactions

---

## 3. Customer

Customers cannot buy products online.

Their account is only used for browsing products and viewing purchase history.

### Features

* Register
* Login
* Forgot Password
* Browse Products
* Search Products
* Filter by Category
* View Product Details
* View Available Stock
* View Product Prices
* View Promotions
* Purchase History
* View Receipt History
* Update Profile
* Change Password

---

# Complete System Workflow

## Admin Workflow

1. Login
2. Add product categories
3. Add products
4. Set prices
5. Enter stock quantity
6. Create staff accounts
7. Monitor inventory
8. View reports

---

## Customer Workflow

1. Register an account.
2. Login.
3. Browse available products.
4. Check prices.
5. Check stock availability.
6. Visit the physical store.
7. Select products.
8. Proceed to the cashier.
9. Inform the cashier that they have a SmartMart account (email, phone number, or customer ID).
10. Pay in cash.
11. View the completed transaction later in Purchase History.

---

## Staff Workflow

1. Login.
2. Open POS.
3. Search or scan products.
4. Add products to cart.
5. Ask whether the customer has a SmartMart account.
6. If yes, search the customer and link the account.
7. Receive cash payment.
8. Enter the cash amount.
9. Automatically calculate change.
10. Complete the transaction.
11. Print receipt.
12. Inventory is automatically updated.
13. Transaction is saved.

---

# Purchase History Workflow

Customer purchases products inside the store.

Staff links the sale to the customer's account before completing the transaction.

Example:

Customer:
John Smith

Products:

* 2 Chips
* 1 Coke

Total:
₱85

Cash:
₱100

Change:
₱15

After completing the transaction, the customer can log in and view:

* Transaction Number
* Date
* Purchased Products
* Quantity
* Total Amount
* Payment Method
* Receipt
* Transaction Status

---

# POS Workflow

Staff Login

↓

Open POS

↓

Search Products

↓

Add to Cart

↓

Search Customer (Optional)

↓

Enter Cash Payment

↓

Calculate Change

↓

Complete Transaction

↓

Print Receipt

↓

Save Sale

↓

Update Inventory

---

# Inventory Workflow

Admin adds products.

↓

Products become available.

↓

Staff sells products.

↓

Inventory decreases automatically.

↓

Admin receives low-stock notifications.

↓

Admin restocks inventory.

---

# Dashboard

## Admin Dashboard

Display:

* Total Products
* Total Categories
* Total Customers
* Total Staff
* Today's Sales
* Weekly Sales
* Monthly Sales
* Best-Selling Products
* Low Stock Products
* Recent Transactions

---

## Staff Dashboard

Display:

* Today's Transactions
* New Sale
* Product Search
* Inventory Summary

---

## Customer Dashboard

Display:

* Welcome Message
* Available Products
* Promotions
* Purchase History
* Profile

---

# Database Tables

* Roles
* Users
* Customers
* Staff
* Categories
* Products
* Inventory
* Sales
* SaleItems
* Receipts
* ActivityLogs

---

# Authentication

* Login
* Registration
* Forgot Password
* JWT Authentication
* Role-Based Access Control
* Password Hashing

---

# Reports

Admin can generate:

* Daily Sales Report
* Weekly Sales Report
* Monthly Sales Report
* Best-Selling Products Report
* Inventory Report
* Low Stock Report
* Customer Purchase Report

---

# Technology Stack

Frontend

* React.js
* Vite
* Tailwind CSS

Backend

* Node.js
* Express.js

Database

* MySQL

Authentication

* JWT

Development Tools

* Visual Studio Code
* XAMPP (MySQL)
* Postman

---

# Project Goal

The goal of SmartMart is to provide a complete convenience store management solution that integrates inventory management, customer management, sales processing, and a Point of Sale (POS) system into one web application. Customers use the website to browse products and access their purchase history, while all purchases are completed in person at the cashier using cash payments. The system improves operational efficiency, maintains accurate inventory records, and provides real-time business reports for the store owner.
