const router = require("express").Router();
const { call } = require("../db");
const { authenticate, requireRole } = require("../middleware/auth");

// GET /api/dashboard
router.get("/", authenticate, requireRole("admin"), async (_req, res) => {
  try {
    const rows = await call("sp_get_dashboard_summary");
    res.json(rows?.[0] || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
