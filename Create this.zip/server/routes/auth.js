const router  = require("express").Router();
const bcrypt  = require("bcryptjs");
const jwt     = require("jsonwebtoken");
const { call } = require("../db");

// POST /api/auth/login
router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password)
    return res.status(400).json({ error: "Username and password are required" });

  try {
    const rows = await call("sp_get_user_by_username", [username]);
    const user = rows?.[0];
    if (!user) return res.status(401).json({ error: "Invalid username or password" });
    if (!user.is_active) return res.status(403).json({ error: "Account is deactivated" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: "Invalid username or password" });

    // Customer must be approved
    if (user.role === "customer" && user.account_status !== "Approved")
      return res.status(403).json({ error: "Account pending approval" });

    const payload = {
      id:       user.id,
      username: user.username,
      role:     user.role,
      name:     user.full_name || `${user.first_name} ${user.last_name}`,
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || "8h",
    });

    res.json({ token, user: payload });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
